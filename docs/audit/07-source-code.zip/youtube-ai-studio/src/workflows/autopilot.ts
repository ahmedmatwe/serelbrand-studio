/**
 * Autopilot: one idempotent cycle, safe to run every couple of hours (launchd).
 *  1. Upload videos the human already approved (private).
 *  2. Capture analytics checkpoints that are due, then diagnose.
 *  3. On a production day (per the content calendar), produce the next video up to the approval request.
 *  4. Write the daily report and notify the human when something needs them.
 * It never approves anything by itself and never publishes publicly.
 */
import { execFile } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import type { AgentContext } from '../agents/base.ts';
import type { StrategyOutput } from '../agents/content-strategy.ts';
import type { TrendResearchOutput } from '../agents/trend-research.ts';
import type { FactCheckReport } from '../agents/schemas.ts';
import type { PublishLog } from '../publishing/publisher.ts';
import { postPublish, produceVideo, publish } from './orchestrator.ts';
import { approve } from '../publishing/approval.ts';
import type { PrePublicationReport } from '../reports/prepublication.ts';
import type { RenderOutput } from '../media/renderer.ts';
import { steps } from './steps.ts';

export interface CycleOptions {
  now?: Date;
  /** Skip production (e.g. analytics-only runs). */
  produce?: boolean;
  notify?: (title: string, body: string) => void;
  renderSize?: 'full' | 'preview';
}

export interface CycleReport {
  startedAt: string;
  published: string[];
  analyticsUpdated: string[];
  produced: { videoId: string; title: string; recommendation: string; claimsToVerify: number; autoApproved?: boolean; autoApproveBlockedBy?: string[]; publishAt?: string } | null;
  skippedProductionReason?: string;
  pendingApprovals: number;
  needsFactReview: { videoId: string; title: string; claims: number }[];
  errors: string[];
}

const LOCK_STALE_MS = 3 * 3600_000;

/**
 * Every condition must hold for a video to be approved without a human.
 * Returns the list of unmet conditions (empty = OK to auto-approve).
 */
export function autoApproveBlockers(r: PrePublicationReport, render: RenderOutput | undefined, minQuality: number): string[] {
  const why: string[] = [];
  if (r.hardBlockers.length) why.push(...r.hardBlockers);
  if (r.complianceScore < 90) why.push(`compliance ${r.complianceScore} < 90`);
  if (r.qualityScore < minQuality) why.push(`quality ${r.qualityScore} < ${minQuality}`);
  if (r.factCheckStatus !== 'verified') why.push(`facts ${r.factCheckStatus}`);
  if (r.copyrightStatus !== 'clear') why.push(`copyright ${r.copyrightStatus}`);
  if (r.monetizationRisk === 'high') why.push('monetization risk high');
  for (const w of r.warnings) if (/^(Quality|Compliance)/.test(w)) why.push(w);
  if (!render) why.push('no render');
  else if (render.measurements.audioScore <= 0) why.push('silent/invalid audio');
  return why;
}

/** Prevents two cycles from overlapping (launchd + a manual run). */
export function acquireLock(path: string, now = Date.now()): boolean {
  if (existsSync(path) && now - statSync(path).mtimeMs < LOCK_STALE_MS) return false;
  mkdirSync(resolve(path, '..'), { recursive: true });
  writeFileSync(path, String(process.pid));
  return true;
}

export const macNotify = (title: string, body: string) => {
  if (process.platform !== 'darwin') return;
  const esc = (s: string) => s.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  execFile('osascript', ['-e', `display notification "${esc(body)}" with title "${esc(title)}" sound name "Glass"`], () => {});
};

const day = (d: Date) => d.toISOString().slice(0, 10);

/** Picks today's long-form calendar entry that has not been produced yet. */
export function todaysPlan(strategy: StrategyOutput | undefined, producedTitles: Set<string>, now: Date) {
  if (!strategy) return undefined;
  return strategy.calendar.find((c) => c.format === 'long' && c.date <= day(now) && !producedTitles.has(c.title));
}

export async function runCycle(ctx: AgentContext, o: CycleOptions = {}): Promise<CycleReport> {
  const now = o.now ?? new Date();
  const notify = o.notify ?? macNotify;
  const rep: CycleReport = { startedAt: now.toISOString(), published: [], analyticsUpdated: [], produced: null, pendingApprovals: 0, needsFactReview: [], errors: [] };
  const log = ctx.logger.child('autopilot');

  // 1) Approved → upload (private).
  for (const v of ctx.repos.videos.list('approved')) {
    const r = await publish(ctx, v.id);
    if (r.status === 'succeeded') rep.published.push(v.id);
    else rep.errors.push(`publish ${v.id}: ${r.error}`);
  }

  // 2) Analytics for uploaded videos, by hours since upload.
  for (const v of ctx.repos.videos.list().filter((x) => x.youtube_video_id)) {
    const pub = ctx.repos.artifacts.latest<PublishLog>(v.id, 'publish_log')?.data;
    if (!pub) continue;
    const hours = (now.getTime() - new Date(pub.uploadedAt).getTime()) / 3600_000;
    const have = new Set(ctx.repos.analytics.forVideo(v.id).map((s) => s.checkpointHours));
    const due = ctx.config.thresholds.analytics.checkpointsHours.filter((h) => h <= hours && !have.has(h));
    if (!due.length) continue;
    const r = await postPublish(ctx, v.id, hours);
    if (r.steps.every((s) => s.status === 'succeeded')) rep.analyticsUpdated.push(v.id);
    else rep.errors.push(`analytics ${v.id}: ${r.steps.find((s) => s.status !== 'succeeded')?.error}`);
  }

  // 3) Production (one long video per production day; its Shorts come with it).
  const producedToday = ctx.repos.videos.list().some((v) => v.created_at.slice(0, 10) === day(now));
  if (o.produce === false) rep.skippedProductionReason = 'production disabled for this run';
  else if (producedToday) rep.skippedProductionReason = 'already produced a video today';
  else {
    try {
      const niche = ctx.config.channel.niche ?? 'business-stories';
      let strategy = ctx.repos.artifacts.latest<StrategyOutput>(null, 'content_strategy')?.data;
      // Plan once (or when the calendar runs out): ideas → 90-day calendar.
      const lastDate = strategy?.calendar.at(-1)?.date;
      if (!strategy || !lastDate || lastDate < day(now)) {
        await steps['trend-research'](ctx, { niche });
        strategy = (await steps['content-strategy'](ctx, { niche, startDate: day(now) })) as StrategyOutput;
      }
      // Scripts rename videos, so remember which calendar entry each video came from.
      const produced = new Set([...ctx.repos.videos.list().map((v) => v.title), ...ctx.repos.artifacts.listKind<{ title: string }>('calendar_entry').map((a) => a.data.title)]);
      const plan = todaysPlan(strategy, produced, now);
      if (!plan) rep.skippedProductionReason = 'no long video scheduled for today';
      else {
        const vid = ctx.repos.videos.create({ title: plan.title, format: 'long', niche });
        ctx.repos.artifacts.save({ videoId: vid.id, kind: 'calendar_entry', agent: 'autopilot', data: plan });
        const r = await produceVideo(ctx, { title: plan.title, videoId: vid.id, format: 'long', niche, render: true, renderSize: o.renderSize ?? 'full' });
        if (!r.completed) rep.errors.push(`produce "${plan.title}": ${r.steps.find((s) => s.status !== 'succeeded')?.error}`);
        const fc = ctx.repos.artifacts.latest<FactCheckReport>(r.videoId, 'fact_check')?.data;
        rep.produced = {
          videoId: r.videoId,
          title: ctx.repos.videos.get(r.videoId)?.title ?? plan.title,
          recommendation: r.report?.recommendation ?? 'incomplete',
          claimsToVerify: fc?.claims.filter((c) => c.humanReviewRequired).length ?? 0,
        };
        // Full automation (opt-in): approve only when every gate passes, then upload right away.
        if (ctx.config.env.AUTO_APPROVE && r.report) {
          const render = ctx.repos.artifacts.latest<RenderOutput>(r.videoId, 'render')?.data;
          const blockers = r.approval ? autoApproveBlockers(r.report, render, ctx.config.thresholds.quality.minScoreToPublish) : ['no approval request (blocked)', ...r.report.hardBlockers];
          if (!blockers.length && r.approval) {
            const publishAt = ctx.config.env.ALLOW_PUBLIC_PUBLISHING ? r.report.proposedPublishAt : undefined;
            approve(ctx, r.approval.id, { by: 'autopilot', visibility: 'private', publishAt, acceptRisks: true, note: 'Auto-approved: every quality, compliance and fact gate passed' });
            const pub = await publish(ctx, r.videoId);
            if (pub.status === 'succeeded') rep.published.push(r.videoId);
            else rep.errors.push(`publish ${r.videoId}: ${pub.error}`);
            rep.produced.autoApproved = true;
            rep.produced.publishAt = publishAt;
          } else {
            rep.produced.autoApproved = false;
            rep.produced.autoApproveBlockedBy = blockers;
          }
        }
      }
    } catch (err) {
      rep.errors.push(`production: ${(err as Error).message}`);
    }
  }

  // 4) What needs the human.
  rep.pendingApprovals = ctx.repos.approvals.pending().length;
  for (const v of ctx.repos.videos.list('reviewed')) {
    const fc = ctx.repos.artifacts.latest<FactCheckReport>(v.id, 'fact_check')?.data;
    const n = fc?.claims.filter((c) => c.humanReviewRequired).length ?? 0;
    if (n) rep.needsFactReview.push({ videoId: v.id, title: v.title, claims: n });
  }
  if (rep.produced?.autoApproved) notify('سر البراند: فيديو اتنشر تلقائياً', `${rep.produced.title.slice(0, 60)}${rep.produced.publishAt ? ` — هيظهر ${rep.produced.publishAt.slice(0, 16).replace('T', ' ')} UTC` : ' (private)'}`);
  else if (rep.produced?.autoApproveBlockedBy) notify('سر البراند: فيديو اتوقف', `مش هيتنشر تلقائياً: ${rep.produced.autoApproveBlockedBy[0]?.slice(0, 90)} — شوفه في لوحة التحكم`);
  else if (rep.produced) notify('سر البراند: فيديو جديد جاهز', `${rep.produced.title.slice(0, 60)} — محتاج مراجعتك في لوحة التحكم`);
  else if (rep.pendingApprovals || rep.needsFactReview.length) notify('سر البراند', `فيه ${rep.pendingApprovals + rep.needsFactReview.length} فيديو مستني مراجعتك`);
  const locked = rep.published.filter((id) => (ctx.repos.artifacts.latest<PublishLog>(id, 'publish_log')?.data.warnings ?? []).some((w) => w.startsWith('YOUTUBE_LOCKED_PRIVATE')));
  if (locked.length) notify('سر البراند: YouTube قفل الفيديو private', 'لازم مراجعة YouTube API (مجانية) عشان النشر العلني التلقائي يشتغل');
  else if (rep.published.length) notify('سر البراند', `اترفع ${rep.published.length} فيديو على القناة`);
  if (rep.errors.length) notify('سر البراند: مشكلة', rep.errors[0]!.slice(0, 120));

  writeDailyReport(ctx, rep, now);
  ctx.audit.record({ actor: 'autopilot', action: 'cycle.completed', details: { published: rep.published.length, produced: rep.produced?.videoId, errors: rep.errors.length } });
  log.info('cycle done', { published: rep.published.length, analytics: rep.analyticsUpdated.length, produced: rep.produced?.videoId ?? null, errors: rep.errors.length });
  return rep;
}

/** Appends the cycle to reports/daily/YYYY-MM-DD.md (Arabic). */
export function writeDailyReport(ctx: AgentContext, rep: CycleReport, now: Date) {
  const dir = resolve(ctx.config.rootDir, 'reports/daily');
  mkdirSync(dir, { recursive: true });
  const path = resolve(dir, `${day(now)}.md`);
  const head = existsSync(path) ? '' : `# التقرير اليومي — ${day(now)}\n\nالتكلفة: $${ctx.cost.spentThisMonth().toFixed(2)} هذا الشهر (حد الميزانية $${ctx.config.env.MONTHLY_BUDGET_USD})\n`;
  const lines = [
    `\n## دورة ${now.toISOString().slice(11, 16)} UTC`,
    `- اترفع (private): ${rep.published.length ? rep.published.join('، ') : 'لا شيء'}`,
    `- تحليلات اتحدّثت: ${rep.analyticsUpdated.length}`,
    rep.produced ? `- فيديو جديد: **${rep.produced.title}** (${rep.produced.recommendation}) — ادعاءات محتاجة تأكيد: ${rep.produced.claimsToVerify}${rep.produced.autoApproved ? ` — ✅ اتوافق واتنشر تلقائياً${rep.produced.publishAt ? ` (موعد الظهور ${rep.produced.publishAt})` : ''}` : rep.produced.autoApproveBlockedBy ? ` — ⛔ متنشرش: ${rep.produced.autoApproveBlockedBy.join('؛ ')}` : ''}` : `- إنتاج: ${rep.skippedProductionReason ?? '—'}`,
    `- مستني موافقتك: ${rep.pendingApprovals} · محتاج تأكيد مصادر: ${rep.needsFactReview.length}`,
    ...rep.errors.map((e) => `- ⚠️ ${e}`),
  ];
  writeFileSync(path, (existsSync(path) ? readFileSync(path, 'utf8') : head) + lines.join('\n') + '\n');
  return path;
}

export function releaseLock(path: string) {
  rmSync(path, { force: true });
}
