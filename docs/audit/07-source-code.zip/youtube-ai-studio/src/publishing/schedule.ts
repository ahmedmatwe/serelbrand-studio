import type { KnowledgeRepo } from '../database/repositories.ts';

/**
 * Proposes a publish time.
 * 1) If the knowledge base holds a publish-time insight backed by enough videos, use it.
 * 2) Otherwise fall back to a stated assumption: evenings in Egypt/Gulf (~19:00 Cairo / 20:00 Riyadh = 17:00 UTC).
 * The fallback is an assumption, not data — the report says so.
 */
export function proposePublishTime(
  knowledge: KnowledgeRepo,
  opts: { now?: Date; minSamples: number; defaultUtcHour?: number },
): { at: string; rationale: string } {
  const now = opts.now ?? new Date();
  const learned = knowledge.byCategory('publish_time').find((k) => k.sample_size >= opts.minSamples && /^utc_hour=\d{1,2}$/.test(k.insight));
  const hour = learned ? Number(learned.insight.split('=')[1]) : opts.defaultUtcHour ?? 17;
  // Next occurrence of that hour, at least 24h out to leave time for review.
  const t = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), hour, 0, 0));
  while (t.getTime() - now.getTime() < 24 * 3600_000) t.setUTCDate(t.getUTCDate() + 1);
  return {
    at: t.toISOString(),
    rationale: learned
      ? `من بيانات القناة (${learned.sample_size} فيديو، ثقة ${Math.round(learned.confidence * 100)}%)`
      : 'افتراض مبدئي: مساء مصر/الخليج — يتحدث بعد 8 فيديوهات',
  };
}
